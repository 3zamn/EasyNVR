define({ "api": [
  {
    "type": "get",
    "url": "/api/v1/discoverdevices",
    "title": "发现设备",
    "group": "channel",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "EasyDarwin.Body.ChannelCount",
            "description": "<p>发现设备总数</p>"
          },
          {
            "group": "200",
            "type": "Array",
            "optional": false,
            "field": "EasyDarwin.Body.Channels",
            "description": "<p>设备列表</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Body.Channels.IP",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Body.Channels.ONVIF",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Body",
            "description": ""
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关",
    "name": "GetApiV1Discoverdevices"
  },
  {
    "type": "get",
    "url": "/api/v1/downloadxlsx",
    "title": "下载配置数据",
    "group": "channel",
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关",
    "name": "GetApiV1Downloadxlsx",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/v1/getchannels",
    "title": "获取通道信息",
    "group": "channel",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "channel",
            "description": "<p>获取指定通道号的通道信息</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "start",
            "description": "<p>分页开始,从零开始</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "limit",
            "description": "<p>分页大小</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "sort",
            "description": "<p>排序字段</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "allowedValues": [
              "ascending",
              "descending"
            ],
            "optional": true,
            "field": "order",
            "description": "<p>排序顺序</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "q",
            "description": "<p>查询参数</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "EasyDarwin.Body.ChannelCount",
            "description": "<p>通道总数</p>"
          },
          {
            "group": "200",
            "type": "Array",
            "optional": false,
            "field": "EasyDarwin.Body.Channels",
            "description": "<p>通道列表</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Body",
            "description": ""
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "EasyDarwin.Body.Channels.Channel",
            "description": "<p>通道号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Body.Channels.Name",
            "description": "<p>通道名称</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "allowedValues": [
              "0",
              "1"
            ],
            "optional": false,
            "field": "EasyDarwin.Body.Channels.Online",
            "description": "<p>在线状态</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Body.Channels.SnapURL",
            "description": "<p>快照链接</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": true,
            "field": "EasyDarwin.Body.Channels.ErrorString",
            "description": "<p>错误码</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关",
    "name": "GetApiV1Getchannels"
  },
  {
    "type": "get",
    "url": "/api/v1/getchannelsconfig",
    "title": "获取通道配置",
    "group": "channel",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "channel",
            "description": "<p>获取指定通道号的通道配置</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "start",
            "description": "<p>分页开始,从零开始</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "limit",
            "description": "<p>分页大小</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "sort",
            "description": "<p>排序字段</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "allowedValues": [
              "ascending",
              "descending"
            ],
            "optional": true,
            "field": "order",
            "description": "<p>排序顺序</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "q",
            "description": "<p>查询参数</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "EasyDarwin.Body.ChannelCount",
            "description": "<p>通道配置总数</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Body.Channels",
            "description": "<p>通道配置列表</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Body",
            "description": ""
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "EasyDarwin.Body.Channels.Channel",
            "description": "<p>通道号</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "allowedValues": [
              "0",
              "1"
            ],
            "optional": false,
            "field": "EasyDarwin.Body.Channels.Enable",
            "description": "<p>是否启用</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "allowedValues": [
              "0",
              "1"
            ],
            "optional": false,
            "field": "EasyDarwin.Body.Channels.OnDemand",
            "description": "<p>按需直播</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Body.Channels.Name",
            "description": "<p>通道名称</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": true,
            "field": "EasyDarwin.Body.Channels.IP",
            "description": "<p>通道IP</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": true,
            "field": "EasyDarwin.Body.Channels.Port",
            "description": "<p>通道端口</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Body.Channels.UserName",
            "description": "<p>用户名</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Body.Channels.Password",
            "description": "<p>密码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "allowedValues": [
              "RTSP",
              "ONVIF"
            ],
            "optional": false,
            "field": "EasyDarwin.Body.Channels.Protocol",
            "description": "<p>接入协议</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Body.Channels.Rtsp",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": true,
            "field": "EasyDarwin.Body.Channels.Onvif",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": true,
            "field": "EasyDarwin.Body.Channels.Cdn",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "allowedValues": [
              "0",
              "1"
            ],
            "optional": false,
            "field": "EasyDarwin.Body.Channels.Audio",
            "description": "<p>开启音频</p>"
          },
          {
            "group": "200",
            "type": "String",
            "allowedValues": [
              "-1",
              "0",
              "..."
            ],
            "optional": false,
            "field": "EasyDarwin.Body.Channels.Record",
            "description": "<p>开启录像</p>"
          },
          {
            "group": "200",
            "type": "String",
            "allowedValues": [
              "TCP",
              "UDP"
            ],
            "optional": false,
            "field": "EasyDarwin.Body.Channels.Transport",
            "description": "<p>传输协议</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关",
    "name": "GetApiV1Getchannelsconfig"
  },
  {
    "type": "get",
    "url": "/api/v1/getchannelstream",
    "title": "获取通道直播链接",
    "group": "channel",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "channel",
            "description": "<p>指定通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "allowedValues": [
              "RTMP",
              "HLS",
              "FLV"
            ],
            "optional": true,
            "field": "protocol",
            "description": "<p>直播协议</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Body.URL",
            "description": "<p>直播链接</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Body.ChannelName",
            "description": "<p>通道名称</p>"
          },
          {
            "group": "200",
            "type": "String",
            "allowedValues": [
              "RTSP",
              "ONVIF"
            ],
            "optional": false,
            "field": "EasyDarwin.Body.DeviceType",
            "description": "<p>接入协议</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Body",
            "description": ""
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关",
    "name": "GetApiV1Getchannelstream"
  },
  {
    "type": "get",
    "url": "/api/v1/getsnap",
    "title": "获取通道快照",
    "group": "channel",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "channel",
            "description": "<p>指定通道号</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK\nimage/jpeg 格式, http body 为图片数据",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关",
    "name": "GetApiV1Getsnap"
  },
  {
    "type": "get",
    "url": "/api/v1/probedevice",
    "title": "ONVIF探测",
    "group": "channel",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "IP",
            "description": "<p>发现的设备IP</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "Username",
            "description": "<p>设备用户名</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "Password",
            "description": "<p>设备密码(明文)</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Body.ONVIF",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Body.RTSP",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Body",
            "description": ""
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关",
    "name": "GetApiV1Probedevice"
  },
  {
    "type": "get",
    "url": "/api/v1/ptzcontrol",
    "title": "云台控制",
    "group": "channel",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "channel",
            "description": "<p>指定通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "allowedValues": [
              "stop",
              "up",
              "down",
              "left",
              "right",
              "zoomin",
              "zoomout",
              "focusin",
              "focusout",
              "aperturein",
              "apertureout"
            ],
            "optional": false,
            "field": "command",
            "description": "<p>动作命令</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "speed",
            "description": "<p>动作速度, 例如5</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关",
    "name": "GetApiV1Ptzcontrol",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Body",
            "description": ""
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/v1/setchannelconfig",
    "title": "保存通道配置",
    "group": "channel",
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关",
    "name": "GetApiV1Setchannelconfig",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "Channel",
            "description": "<p>通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "allowedValues": [
              "0",
              "1"
            ],
            "optional": false,
            "field": "Enable",
            "description": "<p>是否启用</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "allowedValues": [
              "0",
              "1"
            ],
            "optional": false,
            "field": "OnDemand",
            "description": "<p>按需直播</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "Name",
            "description": "<p>通道名称</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "IP",
            "description": "<p>通道IP</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "Port",
            "description": "<p>通道端口</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "UserName",
            "description": "<p>用户名</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "Password",
            "description": "<p>密码</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "allowedValues": [
              "RTSP",
              "ONVIF"
            ],
            "optional": false,
            "field": "Protocol",
            "description": "<p>接入协议</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "Rtsp",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "Onvif",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "Cdn",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "String",
            "allowedValues": [
              "0",
              "1"
            ],
            "optional": false,
            "field": "Audio",
            "description": "<p>开启音频</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "allowedValues": [
              "-1",
              "0",
              "..."
            ],
            "optional": false,
            "field": "Record",
            "description": "<p>开启录像</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "allowedValues": [
              "TCP",
              "UDP"
            ],
            "optional": false,
            "field": "Transport",
            "description": "<p>传输协议</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Body",
            "description": ""
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/v1/startrecord",
    "title": "开始录像",
    "group": "channel",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "channel",
            "description": "<p>指定通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "duration",
            "description": "<p>录像时间(秒)</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": true,
            "field": "savedays",
            "description": "<p>录像保存时长(天)</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关",
    "name": "GetApiV1Startrecord",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Body",
            "description": ""
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/v1/stoprecord",
    "title": "停止录像",
    "group": "channel",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "channel",
            "description": "<p>指定通道号</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关",
    "name": "GetApiV1Stoprecord",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Body",
            "description": ""
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/v1/touchchannelstream",
    "title": "保活通道直播链接",
    "group": "channel",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "channel",
            "description": "<p>指定通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "allowedValues": [
              "RTMP",
              "HLS"
            ],
            "optional": true,
            "field": "protocol",
            "description": "<p>直播协议</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Body.URL",
            "description": "<p>直播链接</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Body.ChannelName",
            "description": "<p>通道名称</p>"
          },
          {
            "group": "200",
            "type": "String",
            "allowedValues": [
              "RTSP",
              "ONVIF"
            ],
            "optional": false,
            "field": "EasyDarwin.Body.DeviceType",
            "description": "<p>接入协议</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Body",
            "description": ""
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关",
    "name": "GetApiV1Touchchannelstream"
  },
  {
    "type": "post",
    "url": "/api/v1/uploadxlsx",
    "title": "上传配置数据",
    "group": "channel",
    "version": "0.0.0",
    "filename": "routers/busi_api.go",
    "groupTitle": "通道相关",
    "name": "PostApiV1Uploadxlsx",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/v1/record/download/:id/:period",
    "title": "下载录像文件",
    "group": "record",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "period",
            "description": "<p>录像开始时间, YYYYMMDDHHmmss</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/record.go",
    "groupTitle": "录像回看",
    "name": "GetApiV1RecordDownloadIdPeriod",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/v1/record/querydaily",
    "title": "按日查询通道录像",
    "group": "record",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "period",
            "description": "<p>日期, YYYYMMDD</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>通道名称</p>"
          },
          {
            "group": "200",
            "type": "Array",
            "optional": false,
            "field": "list",
            "description": "<p>当天的录像列表</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "list.name",
            "description": "<p>通道名称</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "list.startAt",
            "description": "<p>开始时间, YYYYMMDDHHmmss</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "list.duration",
            "description": "<p>录像时长(秒)</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "list.hls",
            "description": "<p>录像播放链接</p>"
          },
          {
            "group": "200",
            "type": "Boolean",
            "optional": false,
            "field": "list.important",
            "description": "<p>重要标记</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/record.go",
    "groupTitle": "录像回看",
    "name": "GetApiV1RecordQuerydaily"
  },
  {
    "type": "get",
    "url": "/api/v1/record/querydevices",
    "title": "查询录像通道",
    "group": "record",
    "version": "0.0.0",
    "filename": "routers/record.go",
    "groupTitle": "录像回看",
    "name": "GetApiV1RecordQuerydevices",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "start",
            "description": "<p>分页开始,从零开始</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "limit",
            "description": "<p>分页大小</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "sort",
            "description": "<p>排序字段</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "allowedValues": [
              "ascending",
              "descending"
            ],
            "optional": true,
            "field": "order",
            "description": "<p>排序顺序</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": true,
            "field": "q",
            "description": "<p>查询参数</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "total",
            "description": "<p>总数</p>"
          },
          {
            "group": "200",
            "type": "Array",
            "optional": false,
            "field": "rows",
            "description": "<p>分页数据</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "rows.id",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "rows.name",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "rows.updateAt",
            "description": "<p>更新时间, YYYY-MM-DD HH:mm:ss</p>"
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/v1/record/queryflags",
    "title": "按通道统计所有录像记录",
    "group": "record",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>通道号</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "key",
            "description": "<p>月份, YYYYMM</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "value",
            "description": "<p>标记当月每一天是否有录像, 0 - 没有录像, 1 - 有录像</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "成功示例",
          "content": "{201803: \"0000000011000000000000000000000\"}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routers/record.go",
    "groupTitle": "录像回看",
    "name": "GetApiV1RecordQueryflags"
  },
  {
    "type": "get",
    "url": "/api/v1/record/querymonthly",
    "title": "按月查询通道录像记录",
    "group": "record",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "period",
            "description": "<p>月份, YYYYMM</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "flag",
            "description": "<p>标记当月每一天是否有录像, 0 - 没有录像, 1 - 有录像</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "成功示例",
          "content": "\"0000000011000000000000000000000\"",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routers/record.go",
    "groupTitle": "录像回看",
    "name": "GetApiV1RecordQuerymonthly"
  },
  {
    "type": "get",
    "url": "/api/v1/record/remove",
    "title": "删除单条录像",
    "group": "record",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "period",
            "description": "<p>录像开始时间, YYYYMMDDHHmmss</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/record.go",
    "groupTitle": "录像回看",
    "name": "GetApiV1RecordRemove",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/v1/record/removedaily",
    "title": "按天删除通道录像",
    "group": "record",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "period",
            "description": "<p>日期, YYYYMMDD</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/record.go",
    "groupTitle": "录像回看",
    "name": "GetApiV1RecordRemovedaily",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/v1/record/removedevice",
    "title": "删除通道所有录像",
    "group": "record",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>通道号</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/record.go",
    "groupTitle": "录像回看",
    "name": "GetApiV1RecordRemovedevice",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/v1/record/setimportant",
    "title": "重要录像标记",
    "group": "record",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "period",
            "description": "<p>录像开始时间, YYYYMMDDHHmmss</p>"
          },
          {
            "group": "Parameter",
            "type": "Boolean",
            "allowedValues": [
              "0",
              "1"
            ],
            "optional": false,
            "field": "important",
            "description": "<p>重要标记</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/record.go",
    "groupTitle": "录像回看",
    "name": "GetApiV1RecordSetimportant",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/v1/record/video/:operate/:id/:starttime/:endtime",
    "title": "指定时间段录像播放及下载",
    "group": "record",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "allowedValues": [
              "play",
              "download"
            ],
            "optional": false,
            "field": "operate",
            "description": "<p>调用操作 play:播放 download下载</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "id",
            "description": "<p>通道号</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "starttime",
            "description": "<p>开始时间, YYYYMMDDHHmmss</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "endtime",
            "description": "<p>结束时间, YYYYMMDDHHmmss</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "播放示例",
          "content": "http://localhost:10800/api/v1/record/video/play/1/20180911101139/20180911101248",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "下载示例",
          "content": "http://localhost:10800/api/v1/record/video/download/1/20180911101139/20180911101248",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routers/record.go",
    "groupTitle": "录像回看",
    "name": "GetApiV1RecordVideoOperateIdStarttimeEndtime"
  },
  {
    "type": "get",
    "url": "/api/v1/getserverinfo",
    "title": "获取平台运行信息",
    "group": "sys",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Body.Authorization",
            "description": "<p>授权对象</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Body.Hardware",
            "description": "<p>硬件信息</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Body.InterfaceVersion",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "Boolean",
            "optional": false,
            "field": "EasyDarwin.Body.IsDemo",
            "description": "<p>演示版本</p>"
          },
          {
            "group": "200",
            "type": "Boolean",
            "optional": false,
            "field": "EasyDarwin.Body.LiveSteamAuth",
            "description": "<p>直播页面鉴权</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "EasyDarwin.Body.RemainDays",
            "description": "<p>剩余授权时间(天)</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Body.RunningTime",
            "description": "<p>运行时间</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Body.ServerTime",
            "description": "<p>系统时间</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Body.StartUpTime",
            "description": "<p>启动时间</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Body.Server",
            "description": "<p>软件信息</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "EasyDarwin.Body.ChannelCount",
            "description": "<p>通道数</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Body.VersionType",
            "description": "<p>版本类型</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Body",
            "description": ""
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/sys_api.go",
    "groupTitle": "系统接口",
    "name": "GetApiV1Getserverinfo"
  },
  {
    "type": "get",
    "url": "/api/v1/getuserinfo",
    "title": "获取当前登录用户信息",
    "group": "sys",
    "version": "0.0.0",
    "filename": "routers/sys_api.go",
    "groupTitle": "系统接口",
    "name": "GetApiV1Getuserinfo",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Body",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Body.id",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Body.name",
            "description": "<p>用户名</p>"
          },
          {
            "group": "200",
            "type": "String[]",
            "optional": true,
            "field": "EasyDarwin.Body.roles",
            "description": "<p>角色列表</p>"
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/v1/login",
    "title": "登录",
    "group": "sys",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "username",
            "description": "<p>用户名</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "password",
            "description": "<p>密码(经过md5加密,32位长度,不带中划线,不区分大小写)</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Body.Token",
            "description": ""
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "EasyDarwin.Body.TokenTimeout",
            "description": "<p>Token 超时(秒)</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Body",
            "description": ""
          }
        ]
      },
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200\n{\"token\":\"mDC4tu-ig\"}\nSet-Cookie: token=mDC4tu-ig; Path=/; Expires=Thu, 15 Nov 2018 03:13:26 GMT; Max-Age=604800; HttpOnly",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routers/sys_api.go",
    "groupTitle": "系统接口",
    "name": "GetApiV1Login"
  },
  {
    "type": "get",
    "url": "/api/v1/logout",
    "title": "登出",
    "group": "sys",
    "version": "0.0.0",
    "filename": "routers/sys_api.go",
    "groupTitle": "系统接口",
    "name": "GetApiV1Logout",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Body",
            "description": ""
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/v1/modifypassword",
    "title": "修改密码",
    "group": "sys",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "oldpassword",
            "description": "<p>旧密码, MD5密文</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "newpassword",
            "description": "<p>新密码, MD5密文</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Body.Token",
            "description": ""
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "EasyDarwin.Body.TokenTimeout",
            "description": "<p>Token 超时(秒)</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin",
            "description": ""
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Header",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.CSeq",
            "description": "<p>交互序列号</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.Version",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.MessageType",
            "description": "<p>消息类型</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorNum",
            "description": "<p>错误码</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "EasyDarwin.Header.ErrorString",
            "description": "<p>错误信息</p>"
          },
          {
            "group": "200",
            "type": "Object",
            "optional": false,
            "field": "EasyDarwin.Body",
            "description": ""
          }
        ]
      },
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200\n{\"token\":\"mDC4tu-ig\"}\nSet-Cookie: token=mDC4tu-ig; Path=/; Expires=Thu, 15 Nov 2018 03:13:26 GMT; Max-Age=604800; HttpOnly",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routers/sys_api.go",
    "groupTitle": "系统接口",
    "name": "GetApiV1Modifypassword"
  },
  {
    "type": "get",
    "url": "/api/v1/restart",
    "title": "重启服务",
    "group": "sys",
    "version": "0.0.0",
    "filename": "routers/sys_api.go",
    "groupTitle": "系统接口",
    "name": "GetApiV1Restart",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  }
] });
