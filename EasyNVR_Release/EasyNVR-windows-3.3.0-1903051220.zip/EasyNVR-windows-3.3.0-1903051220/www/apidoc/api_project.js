define({
  "name": "EasyNVR",
  "title": "EasyNVR 接口文档",
  "version": "3.3.0",
  "description": "EasyNVR Minimal But Not Simplify",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2019-02-18T01:54:01.868Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
