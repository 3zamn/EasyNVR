define({
  "name": "EasyNVR",
  "title": "EasyNVR 接口文档",
  "version": "3.3.1",
  "description": "EasyNVR Minimal But Not Simplify",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2019-07-01T06:06:16.505Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
