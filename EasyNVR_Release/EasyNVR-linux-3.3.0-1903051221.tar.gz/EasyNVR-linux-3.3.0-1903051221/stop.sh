#!/bin/bash
CWD=$(cd "$(dirname $0)";pwd)
"$CWD"/easynvr stop
"$CWD"/easynvr uninstall 