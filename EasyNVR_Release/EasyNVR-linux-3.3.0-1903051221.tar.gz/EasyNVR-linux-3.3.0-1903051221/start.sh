#!/bin/bash
CWD=$(cd "$(dirname $0)";pwd)
"$CWD"/easynvr install
"$CWD"/easynvr start 